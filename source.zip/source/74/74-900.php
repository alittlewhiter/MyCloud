<body>
<?php
  $referer = @$_SERVER['HTTP_REFERER'];
  echo 'Referer: ', $referer;
?>
</body> 
