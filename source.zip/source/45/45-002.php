<?php
  session_start();
  // 登录确认…省略
?>
<body>
<form action="45-003.php" method="POST">
新密码<input name="pwd" type="password"><BR>
<input type=submit value="修改密码">
</form>
</body>
