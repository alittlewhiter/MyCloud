<?php
  session_start();
?>
<html>
<head><title>7. 面向手机的Web应用程序安全</title></head>
<body>
<b>注：中文版本章已经删除，仅供参考</b>
7. 面向手机的Web应用程序安全<br>
7.4 嵌入到URL中的Session ID引起的安全问题<br><br>
<a href="74-001.php">74-001:缓冲页面DEMO</a><br><br>
<a href="phpinfo.php">phpinfo</a><br>
<a href="/">返回首页</a>
</body>
</html>
