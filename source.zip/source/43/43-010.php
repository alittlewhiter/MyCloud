<body>
<a href="<?php echo htmlspecialchars($_GET['url']); ?>">收藏夹</a>
</body>
