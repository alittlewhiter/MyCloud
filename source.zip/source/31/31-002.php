﻿<html>
<head><title>输入个人信息</title></head>
<body>
<form action="31-003.php" method="POST">
姓名<input type="text" name="name"><BR>
邮件地址<input type="text" name="mail"><BR>
性別<input type="radio" name="gender" value="女">女
<input type="radio" name="gender" value="男">男<BR>
<input type="submit" value="确认">
</form>
</html>
