<body>
指向外部网站的链接。
<a href="http://trap.example.com/74/74-900.php">外部链接</a><br>
</body>
