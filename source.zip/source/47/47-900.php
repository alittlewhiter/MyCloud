<html>
<head><title>登录エラー</title></head>
<body>
IDまたは密码が違います。再度認証してください。
<form action="47-901.php" method="POST">
用户名<input type="text" name="id"><BR>
密码<input type="password" name="pwd"><BR>
<input type="submit" value="登录">
</form>
</body>
</html>
