<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD><TITLE>信息收集脚本</TITLE></HEAD>
<BODY>
您的信息已经收到（实际上真的陷阱网站不会显示）<br>
姓　　名:<?php echo @$_POST['name']; ?><BR>
地　　址:<?php echo @$_POST['addr']; ?><BR>
电话号码:<?php echo @$_POST['tel']; ?><BR>
商　　品:<?php echo @$_POST['kind']; ?><BR>
数　　量:<?php echo @$_POST['num']; ?><BR>
信用卡号码:<?php echo @$_POST['card']; ?><BR>
信用卡有效期:<?php echo @$_POST['thru']; ?><BR>
</BODY>
</HTML>
