<?php
  session_start();
?>
<body>
  <a href="http://trap.example.com/462/46-900.cgi">指向站外的链接</a>
</body>
