<body>
<form action="4c-012.php" method="post" enctype="multipart/form-data"> 
文件：  <input type="file" name="imgfile" size="20"><br>
<input type="submit" value="上传">
</form>
</body>
