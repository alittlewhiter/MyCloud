<?php
  session_start();
  // 登录检查（略）
?>
<body>
搜索关键字:<?php echo $_GET['keyword']; ?><BR>
以下略
</body>
