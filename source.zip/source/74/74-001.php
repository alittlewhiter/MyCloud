<?php
  session_start();
?>
<body>
リンク先のページでアドレスバーを确认して、Session IDがURLについているかどうかを确认してください。<br>
<a href="http://example.jp/74/74-002.php">クッションページ（絶対URLで遷移）</a><br>
<a href="74-002.php">クッションページ（相対URLで遷移）</a><br>
</body>
