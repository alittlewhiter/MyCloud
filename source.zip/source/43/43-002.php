<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD><TITLE>○○市大型垃圾收集中心</TITLE></HEAD>
<BODY>
<FORM action="" METHOD=POST>
姓　　名<INPUT size="20" name="name" value="<?php echo @$_POST['name']; ?>"><BR>
住　　所<INPUT size="20" name="addr" value="<?php echo @$_POST['addr']; ?>"><BR>
电话号码<INPUT size="20" name="tel" value="<?php echo @$_POST['tel']; ?>"><BR>
内　　容<INPUT size="10" name="kind" value="<?php echo @$_POST['kind']; ?>">
数量<INPUT size="5" name="num" value="<?php echo @$_POST['num']; ?>"><BR>
<input type=submit value="申请"></FORM>
</BODY>
</HTML>
